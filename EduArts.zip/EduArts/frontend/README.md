# EduBridgeX Frontend (Minimal React scaffold)

## Setup
1. `npm install`
2. `npm start`

This is a very small demo React app with pages for Home, Tutors, Student and Tutor dashboards.
It expects the backend at http://localhost:5000 for tutor listing.

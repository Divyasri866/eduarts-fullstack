import React, { useState } from "react";
import "../styles.css";
import "./Explore.css"; 
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";

function Explore() {
  const categories = [
    {
      name: "Tuition",
      description: "Find tutors and students for home/online tuition.",
      img: "https://media.istockphoto.com/id/182352776/photo/home-schooling.jpg?s=612x612&w=0&k=20&c=F7vYom5O_rhQNn4S923qv5Uwy9P4ja6tFP1oWe4FOrw="
    },
    {
      name: "Arts",
      description: "Music, Dance, Drawing, and Photography.",
      img: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4"
    },
    {
      name: "Programming & Coding",
      description: "Web design, coding, robotics, and tech learning.",
      img: "https://images.unsplash.com/photo-1518770660439-4636190af475"
    },
  ];

  const [selectedCategory, setSelectedCategory] = useState("");
  const [role, setRole] = useState(""); 
  const [formData, setFormData] = useState({});
  const [showFindButton, setShowFindButton] = useState(false);
  const [searchResults, setSearchResults] = useState([]);

  // Mock data
  const mockData = [
    { name: "Alice", role: "Tutor", category: "Tuition", city: "Hyderabad", contact: "9876543210", coordinates: [17.3850, 78.4867] },
    { name: "Bob", role: "Student", category: "Tuition", city: "Hyderabad", contact: "9123456780", coordinates: [17.3850, 78.4867] },
    { name: "Charlie", role: "Tutor", category: "Arts", city: "Delhi", contact: "9988776655", coordinates: [28.6139, 77.2090] },
    { name: "David", role: "Student", category: "Programming & Coding", city: "Bangalore", contact: "9012345678", coordinates: [12.9716, 77.5946] },
  ];

  // Category selection
  const handleCategorySelect = (cat) => {
    setSelectedCategory(cat);
    setRole("");
    setFormData({});
    setShowFindButton(false);
    setSearchResults([]);
  };

  // Role selection
  const handleRoleSelect = (selectedRole) => {
    setRole(selectedRole);
    setFormData({});
    setShowFindButton(false);
    setSearchResults([]);
  };

  // Form input change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Form submission
  const handleFormSubmit = (e) => {
    e.preventDefault();
    alert(`${role} form submitted successfully!`);
    setShowFindButton(true); // Show Find Opposite Role button
  };

  // Find opposite role (Student ↔ Tutor)
  const handleFindOppositeRole = () => {
    const results = mockData.filter(
      (d) =>
        d.category === selectedCategory &&
        d.role !== role &&
        d.city.toLowerCase() === formData.city.toLowerCase()
    );
    setSearchResults(results);
  };

  return (
    <div className="explore-page">
      <h1 className="page-title">Explore Categories</h1>

      {/* Categories */}
      <div className="category-grid">
        {categories.map((cat) => (
          <div
            key={cat.name}
            className={`category-card ${selectedCategory === cat.name ? "active" : ""}`}
            onClick={() => handleCategorySelect(cat.name)}
          >
            <img src={cat.img} alt={cat.name} className="category-img" />
            <h3>{cat.name}</h3>
            <p>{cat.description}</p>
          </div>
        ))}
      </div>

      {/* Role Selection */}
      {selectedCategory && (
        <div className="role-selection">
          <h2>Are you a Student or Tutor for <span>{selectedCategory}</span>?</h2>
          <button
            className={role === "Student" ? "active" : ""}
            onClick={() => handleRoleSelect("Student")}
          >
            Student
          </button>
          <button
            className={role === "Tutor" ? "active" : ""}
            onClick={() => handleRoleSelect("Tutor")}
          >
            Tutor
          </button>
        </div>
      )}

      {/* Category-specific Form */}
      {role && (
        <div className="role-form-container">
          <h2>{role} Form - {selectedCategory}</h2>
          <form onSubmit={handleFormSubmit}>
            {/* Personal Info */}
            <div className="form-section">
              <h3>Personal Info</h3>
              <input type="text" name="name" placeholder="Full Name" value={formData.name || ""} onChange={handleChange} required />
              <input type="email" name="email" placeholder="Email" value={formData.email || ""} onChange={handleChange} required />
              <input type="text" name="city" placeholder="City" value={formData.city || ""} onChange={handleChange} required />
              <input type="text" name="contact" placeholder="Phone Number" value={formData.contact || ""} onChange={handleChange} required />
            </div>

            {/* Tuition */}
            {selectedCategory === "Tuition" && role === "Student" && (
              <div className="form-section">
                <h3>Education Details</h3>
                <input type="text" name="school" placeholder="School / College Name" value={formData.school || ""} onChange={handleChange} required />
                <input type="text" name="grade" placeholder="Grade / Class" value={formData.grade || ""} onChange={handleChange} required />
                <input type="text" name="subjects" placeholder="Subjects Interested" value={formData.subjects || ""} onChange={handleChange} />
              </div>
            )}
            {selectedCategory === "Tuition" && role === "Tutor" && (
              <div className="form-section">
                <h3>Professional Details</h3>
                <input type="text" name="qualification" placeholder="Qualification" value={formData.qualification || ""} onChange={handleChange} required />
                <input type="text" name="method" placeholder="Teaching Method (Online / Offline / Home)" value={formData.method || ""} onChange={handleChange} required />
                <input type="text" name="subjects" placeholder="Subjects You Teach" value={formData.subjects || ""} onChange={handleChange} required />
                <input type="text" name="timings" placeholder="Available Timings" value={formData.timings || ""} onChange={handleChange} />
              </div>
            )}

            {/* Arts */}
            {selectedCategory === "Arts" && role === "Student" && (
              <div className="form-section">
                <h3>Arts Interests</h3>
                <input type="text" name="artsType" placeholder="Music / Dance / Drawing / Photography" value={formData.artsType || ""} onChange={handleChange} required />
              </div>
            )}
            {selectedCategory === "Arts" && role === "Tutor" && (
              <div className="form-section">
                <h3>Arts Teaching Details</h3>
                <input type="text" name="artsQualification" placeholder="Arts Qualification / Experience" value={formData.artsQualification || ""} onChange={handleChange} required />
                <input type="text" name="method" placeholder="Teaching Method (Online / Offline / Home)" value={formData.method || ""} onChange={handleChange} required />
              </div>
            )}

            {/* Programming */}
            {selectedCategory === "Programming & Coding" && role === "Student" && (
              <div className="form-section">
                <h3>Programming Interests</h3>
                <input type="text" name="languages" placeholder="Programming Languages / Technologies Interested" value={formData.languages || ""} onChange={handleChange} required />
              </div>
            )}
            {selectedCategory === "Programming & Coding" && role === "Tutor" && (
              <div className="form-section">
                <h3>Programming Teaching Details</h3>
                <input type="text" name="languages" placeholder="Programming Languages / Technologies You Teach" value={formData.languages || ""} onChange={handleChange} required />
                <input type="text" name="method" placeholder="Teaching Method (Online / Offline / Home)" value={formData.method || ""} onChange={handleChange} required />
                <input type="text" name="timings" placeholder="Available Timings" value={formData.timings || ""} onChange={handleChange} />
              </div>
            )}

            <button type="submit" className="submit-btn">Submit</button>
          </form>

          {/* Find Opposite Role Button */}
          {showFindButton && (
            <div style={{ textAlign: "center", marginTop: "20px" }}>
              <button className="submit-btn" onClick={handleFindOppositeRole}>
                {role === "Student" ? "Find Tutors" : "Find Students"}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Search Results + Map */}
      {searchResults.length > 0 && (
        <>
          <div className="search-results">
            <h2>Nearby {role === "Student" ? "Tutors" : "Students"}</h2>
            {searchResults.map((res, i) => (
              <div key={i} className="search-card">
                <h3>{res.name}</h3>
                <p>City: {res.city}</p>
                <p>Phone: {res.contact}</p>
              </div>
            ))}
          </div>

          <div className="map-container">
            <h2>Nearby {role === "Student" ? "Tutors" : "Students"} on Map</h2>
            <MapContainer center={searchResults[0].coordinates} zoom={10} style={{ height: "400px", width: "100%" }}>
              <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
              {searchResults.map((res, i) => (
                <Marker key={i} position={res.coordinates}>
                  <Popup>
                    {res.name} <br />
                    {res.role} <br />
                    Contact: {res.contact}
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>
        </>
      )}
    </div>
  );
}

export default Explore;

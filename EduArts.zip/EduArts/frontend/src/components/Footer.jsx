import React from "react";

function Footer() {
  return (
    <footer>
      <p>© {new Date().getFullYear()} EduArts. All Rights Reserved.</p>
    </footer>
  );
}

export default Footer;
